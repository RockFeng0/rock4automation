# 名单

###  以下这些项目，鼓舞了我们，成就了 Appium。

* [Apple UIAutomation](http://developer.apple.com/library/ios/#documentation/DeveloperTools/Reference/UIAutomationRef/_index.html)
* [GhostDriver](https://github.com/detro/ghostdriver)
* [IOS Auto](https://github.com/penguinho/applecart)
* [IOS Driver](https://github.com/ios-driver/ios-driver)
* [Mechanic.js](https://github.com/jaykz52/mechanic)
* [node-webkit](https://github.com/rogerwang/node-webkit)
* [Remote Debug](https://github.com/leftlogic/remote-debug)
* [Selenium Project](http://code.google.com/p/selenium/)
* [ios-webkit-debug-proxy](https://github.com/google/ios-webkit-debug-proxy)
