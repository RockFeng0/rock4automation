# 列出 Appium 服务器支持的客户端库

* [https://github.com/appium/ruby_lib](https://github.com/appium/ruby_lib) - Ruby
* [https://github.com/appium/python-client](https://github.com/appium/python-client) - Python
* [https://github.com/appium/java-client](https://github.com/appium/java-client) - Java
* [https://github.com/admc/wd](https://github.com/admc/wd) - JavaScript (Node.js)
* [https://github.com/appium/php-client](https://github.com/appium/php-client) - PHP
* [https://github.com/appium/appium-dotnet-driver](https://github.com/appium/appium-dotnet-driver) - C# (.NET)

安装教程请参见各自库的文档。
